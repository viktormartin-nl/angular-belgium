export const environment = {
  production: true,
};

export const url = 'http://localhost:3000/';
