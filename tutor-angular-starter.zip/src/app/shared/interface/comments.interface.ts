export interface Comments {
  id?: number;
  userId?: number;
  title: string;
  description: string;
  createdAt: string;
}
