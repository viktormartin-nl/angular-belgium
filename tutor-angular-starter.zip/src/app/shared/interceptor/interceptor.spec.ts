import { Interceptor } from './interceptor';

describe('Interceptor', () => {
  it('should create an instance', () => {
    expect(new Interceptor()).toBeTruthy();
  });
});
