import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deleted-popup',
  templateUrl: './deleted-popup.component.html',
  styleUrls: ['./deleted-popup.component.scss'],
})
export class DeletedPopup implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
